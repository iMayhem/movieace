/**
 * ============================================================================
 * MovieAce VPS Resolver — High-Performance Metadata & Stream Resolution API
 * ============================================================================
 * 
 * Architecture:
 *   Vue Frontend → Node.js Resolver (this server) → Moviebox H5 API
 *                                                  ↓
 *                                    Nginx Proxy → CDN Streams
 * 
 * This server handles:
 *   1. Guest session cookie management (auto-refresh)
 *   2. Search & metadata resolution from Moviebox API
 *   3. Stream URL extraction & rewriting to route through Nginx
 *   4. Subtitle fetching & SRT → WebVTT conversion
 *   5. In-memory caching for blazing-fast responses
 * 
 * Port: 8080 (internal, proxied by Nginx on port 80/443)
 * ============================================================================
 */

import express from 'express';
import cors from 'cors';
import axios from 'axios';
import NodeCache from 'node-cache';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8080;
const NGINX_PROXY_BASE = process.env.NGINX_PROXY_BASE || 'http://161.118.191.46';

// ============================================================================
// Cache Configuration
// ============================================================================
const guestCookieCache = new NodeCache({ stdTTL: 3600 }); // 1 hour
const searchCache = new NodeCache({ stdTTL: 1800 }); // 30 minutes
const streamCache = new NodeCache({ stdTTL: 600 }); // 10 minutes

// ============================================================================
// Middleware
// ============================================================================
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Range']
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
});

// ============================================================================
// Moviebox API Client Configuration
// ============================================================================
const MOVIEBOX_API_BASE = 'https://h5.aoneroom.com';
const MOVIEBOX_BFF_BASE = 'https://h5.aoneroom.com/wefeed-h5api-bff';

const movieboxClient = axios.create({
  timeout: 15000,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9',
    'Origin': 'https://moviebox.pk',
    'Referer': 'https://moviebox.pk/'
  }
});

// ============================================================================
// Guest Cookie Manager
// ============================================================================
async function getGuestCookie() {
  const cached = guestCookieCache.get('guest_cookie');
  if (cached) {
    console.log('[COOKIE] Using cached guest session');
    return cached;
  }

  try {
    console.log('[COOKIE] Fetching new guest session...');
    const response = await movieboxClient.get(
      `${MOVIEBOX_API_BASE}/wefeed-h5-bff/app/get-latest-app-pkgs`,
      {
        params: { app_name: 'moviebox' }
      }
    );

    const cookies = response.headers['set-cookie'];
    if (!cookies || cookies.length === 0) {
      throw new Error('No cookies received from Moviebox API');
    }

    // Extract session cookie
    const sessionCookie = cookies
      .map(c => c.split(';')[0])
      .join('; ');

    guestCookieCache.set('guest_cookie', sessionCookie);
    console.log('[COOKIE] New guest session established');
    return sessionCookie;
  } catch (error) {
    console.error('[COOKIE_ERROR]', error.message);
    throw new Error('Failed to establish guest session with Moviebox API');
  }
}

// ============================================================================
// Search Endpoint
// ============================================================================
app.get('/vps-proxy/search', async (req, res) => {
  try {
    const { q, type = 'movie' } = req.query;

    if (!q) {
      return res.status(400).json({ error: 'Query parameter "q" is required' });
    }

    const cacheKey = `search:${type}:${q}`;
    const cached = searchCache.get(cacheKey);
    if (cached) {
      console.log('[SEARCH] Cache hit');
      return res.json(cached);
    }

    const cookie = await getGuestCookie();
    
    console.log(`[SEARCH] Querying Moviebox API: "${q}" (${type})`);
    const response = await movieboxClient.get(
      `${MOVIEBOX_BFF_BASE}/subject/search`,
      {
        params: {
          keyword: q,
          size: 20,
          page: 1
        },
        headers: {
          'Cookie': cookie
        }
      }
    );

    const data = response.data?.data || {};
    const items = data.list || [];

    // Filter by type and format results
    const results = items
      .filter(item => {
        if (type === 'movie') return item.category === 0;
        if (type === 'tv') return item.category === 1;
        return true;
      })
      .map(item => ({
        id: item.id,
        title: item.title,
        year: item.year,
        posterPath: item.poster,
        backdropPath: item.banner,
        category: item.category === 0 ? 'movie' : 'tv',
        rating: item.score,
        raw: {
          detailPath: item.detailPath,
          boxType: item.boxType
        }
      }));

    const result = { results, total: results.length };
    searchCache.set(cacheKey, result);

    res.json(result);
  } catch (error) {
    console.error('[SEARCH_ERROR]', error.message);
    res.status(500).json({
      error: 'Search failed',
      message: error.message
    });
  }
});

// ============================================================================
// Stream Resolution Endpoint
// ============================================================================
app.get('/vps-proxy/resolve', async (req, res) => {
  try {
    const { detailPath, id, type = 'movie', season = 1, episode = 1 } = req.query;

    if (!detailPath || !id) {
      return res.status(400).json({
        error: 'Parameters "detailPath" and "id" are required'
      });
    }

    const cacheKey = `stream:${id}:${type}:${season}:${episode}`;
    const cached = streamCache.get(cacheKey);
    if (cached) {
      console.log('[RESOLVE] Cache hit');
      return res.json(cached);
    }

    const cookie = await getGuestCookie();

    console.log(`[RESOLVE] Fetching stream data for ${type} ID: ${id}`);
    
    // Step 1: Get detail page to extract download/play info
    const detailResponse = await movieboxClient.get(
      `${MOVIEBOX_BFF_BASE}${detailPath}`,
      {
        headers: { 'Cookie': cookie }
      }
    );

    const detail = detailResponse.data?.data || {};
    
    // Step 2: Get download/stream links
    let downloadParams = {
      id: id,
      category: type === 'movie' ? 0 : 1
    };

    if (type === 'tv') {
      downloadParams.episode = parseInt(episode);
      downloadParams.season = parseInt(season);
    }

    const downloadResponse = await movieboxClient.get(
      `${MOVIEBOX_BFF_BASE}/subject/download`,
      {
        params: downloadParams,
        headers: { 'Cookie': cookie }
      }
    );

    const downloadData = downloadResponse.data?.data || {};
    
    if (!downloadData.list || downloadData.list.length === 0) {
      return res.status(404).json({
        error: 'No streaming sources available',
        message: 'This content may not be available for streaming'
      });
    }

    // Step 3: Extract and rewrite stream URLs to route through Nginx
    const streamOptions = downloadData.list.map(item => {
      const originalUrl = item.path || item.url;
      const proxiedUrl = `${NGINX_PROXY_BASE}/proxy-media/${originalUrl}`;
      
      return {
        quality: item.quality || 'HD',
        format: item.format || 'MP4',
        size: item.size,
        url: proxiedUrl,
        originalUrl: originalUrl
      };
    });

    // Sort by quality (highest first)
    streamOptions.sort((a, b) => {
      const qualityOrder = { '4K': 4, '1080P': 3, '720P': 2, 'HD': 1, 'SD': 0 };
      return (qualityOrder[b.quality] || 0) - (qualityOrder[a.quality] || 0);
    });

    // Step 4: Extract subtitles
    const subtitles = (downloadData.subtitles || []).map(sub => ({
      language: sub.language,
      languageCode: sub.lang || 'en',
      url: `${NGINX_PROXY_BASE}/vps-proxy/subtitle?url=${encodeURIComponent(sub.url)}`
    }));

    const result = {
      title: detail.title || 'Unknown',
      stream: streamOptions[0], // Default to highest quality
      options: streamOptions,
      captions: subtitles,
      metadata: {
        duration: detail.duration,
        year: detail.year,
        rating: detail.score
      }
    };

    streamCache.set(cacheKey, result);
    res.json(result);

  } catch (error) {
    console.error('[RESOLVE_ERROR]', error.message);
    res.status(500).json({
      error: 'Stream resolution failed',
      message: error.message
    });
  }
});

// ============================================================================
// Subtitle Proxy & Conversion (SRT → WebVTT)
// ============================================================================
app.get('/vps-proxy/subtitle', async (req, res) => {
  try {
    const { url } = req.query;

    if (!url) {
      return res.status(400).json({ error: 'Parameter "url" is required' });
    }

    console.log('[SUBTITLE] Fetching:', url);
    
    const response = await axios.get(url, {
      responseType: 'text',
      timeout: 10000
    });

    let content = response.data;

    // Convert SRT to WebVTT if needed
    if (!content.startsWith('WEBVTT')) {
      content = convertSRTtoWebVTT(content);
    }

    res.setHeader('Content-Type', 'text/vtt; charset=utf-8');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.send(content);

  } catch (error) {
    console.error('[SUBTITLE_ERROR]', error.message);
    res.status(500).json({
      error: 'Subtitle fetch failed',
      message: error.message
    });
  }
});

/**
 * Convert SRT subtitle format to WebVTT
 */
function convertSRTtoWebVTT(srt) {
  let vtt = 'WEBVTT\n\n';
  
  // Replace SRT timestamp format (00:00:00,000) with WebVTT format (00:00:00.000)
  vtt += srt.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
  
  return vtt;
}

// ============================================================================
// Health Check
// ============================================================================
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    cache: {
      guestCookie: guestCookieCache.keys().length > 0,
      searches: searchCache.keys().length,
      streams: streamCache.keys().length
    }
  });
});

// ============================================================================
// Error Handler
// ============================================================================
app.use((err, req, res, next) => {
  console.error('[ERROR]', err);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message
  });
});

// ============================================================================
// Start Server
// ============================================================================
app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('═══════════════════════════════════════════════════════════');
  console.log('  MovieAce VPS Resolver — High-Performance Streaming API');
  console.log('═══════════════════════════════════════════════════════════');
  console.log(`  Status: ONLINE`);
  console.log(`  Port: ${PORT}`);
  console.log(`  Nginx Proxy: ${NGINX_PROXY_BASE}`);
  console.log(`  Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log('');
  console.log('  Endpoints:');
  console.log(`    GET  /health                    - Health check`);
  console.log(`    GET  /vps-proxy/search          - Search movies/TV`);
  console.log(`    GET  /vps-proxy/resolve         - Resolve stream URLs`);
  console.log(`    GET  /vps-proxy/subtitle        - Fetch & convert subtitles`);
  console.log('═══════════════════════════════════════════════════════════');
  console.log('');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[SHUTDOWN] Received SIGTERM, closing server...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('[SHUTDOWN] Received SIGINT, closing server...');
  process.exit(0);
});
